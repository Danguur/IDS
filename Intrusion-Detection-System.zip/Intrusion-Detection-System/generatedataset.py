import pandas as pd

# Sample preprocessed dataset
data = {
    "feature1": [0.1, 0.5, 0.3, 0.7, 0.2],
    "feature2": [0.6, 0.8, 0.2, 0.4, 0.9],
    "feature3": [0.3, 0.7, 0.5, 0.1, 0.8],
    "label": ["malicious", "phishing", "benign", "keylogging", "benign"]
}

# Create DataFrame
df = pd.DataFrame(data)

# Save to CSV
df.to_csv("preprocessed_dataset.csv", index=False)

print("Dataset saved as preprocessed_dataset.csv")
